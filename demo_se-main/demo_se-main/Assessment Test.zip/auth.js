const crypto = require('crypto');

const { parseCookies, sendJson } = require('./utils');

// Store all active sessions
const sessions = new Map();

// Set the session validity period to 30 minutes
const SESSION_DURATION = 30 * 60 * 1000;

function createSession(user) {

  // Generate a unique and secure token for the user's session
  // TODO: Generate the token


  // Store the user's ID, role, and session expiry time
  // TODO: Add the session details to the sessions collection


  // Return the generated session token
  // TODO: Return the token
}

function deleteSession(token) {

  // Remove the session associated with the given token
  // TODO: Delete the session
}

function getSession(req) {

  // Read the session token from the request cookies
  // TODO: Extract the session token


  // If no token is available, indicate that no session exists
  // TODO: Handle missing token


  // Find the session associated with the token
  // TODO: Retrieve the session


  // If the session does not exist, indicate that it is invalid
  // TODO: Handle invalid session


  // Check whether the session has expired
  // If expired, remove it and indicate that no valid session exists
  // TODO: Handle expired session


  // Return the valid session along with its token
  // TODO: Return session information
}

function requireAuth(req, res) {

  // Check whether the request belongs to an authenticated user
  // TODO: Retrieve the current session


  // If authentication fails, send an appropriate unauthorized response
  // TODO: Send 401 response and stop execution


  // Return the authenticated user's session
  // TODO: Return the session
}

function requireRole(req, res, allowedRoles) {

  // First verify that the user has a valid session
  // TODO: Perform authentication check


  // Stop execution if authentication fails
  // TODO: Handle failed authentication


  // Check whether the user's role is included in the permitted roles
  // TODO: Validate the user's role


  // If the role is not permitted, send a forbidden response
  // TODO: Send 403 response and stop execution


  // Return the authorized user's session
  // TODO: Return the session
}

// Export all session-related functions
module.exports = {
  createSession,
  deleteSession,
  getSession,
  requireAuth,
  requireRole
};