const { MongoClient } = require('mongodb');

// Get the MongoDB connection URL.
// If it is not provided externally, use the local MongoDB server.
const MONGO_URL = 'mongodb://127.0.0.1:27017';

// Get the database name.
// If it is not provided externally, use the default hospital database name.
const DB_NAME =  'hospital_appointment_db';

// Store the MongoDB client connection
// TODO: Declare a variable to hold the client

// Store the connected database instance
// TODO: Declare a variable to hold the database

async function connectDB() {

  // If a database connection already exists, reuse it
  // TODO: Check whether the database is already available


  // Create a new MongoDB client using the connection URL
  // TODO: Create the MongoDB client


  // Establish a connection with MongoDB
  // TODO: Connect the client


  // Select the required database
  // TODO: Get the database using the database name


  // Return the connected database
  // TODO: Return the database
}

async function closeDB() {

  // If a MongoDB client exists, close the connection
  // TODO: Check whether the client exists


  // Close the MongoDB connection
  // TODO: Close the client
}

// Export the functions required by other modules
// TODO: Export the database connection and closing functions
module.exports = {
  
};