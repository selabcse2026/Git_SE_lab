function sendJson(res, statusCode, data, extraHeaders = {}) {

  // Send a response with the given HTTP status code
  // and JSON content type.
  // Include any additional headers provided by the caller.
  // TODO: Implement the response headers


  // Convert the response data into JSON
  // and send it to the client.
  // TODO: Send the JSON response
}


function readJson(req) {

  // Read the complete request body sent by the client.
  // TODO: Create and return a Promise

  // Store the incoming request data
  // TODO: Create a variable to collect the request body


  // Handle incoming chunks of request data.
  // Add each chunk to the request body.
  // Reject the request if the body exceeds 1 MB.
  // TODO: Implement data handling


  // Handle completion of the request body.
  // If no body is provided, return an empty object.
  // Otherwise, convert the JSON text into a JavaScript object.
  // Reject the request when invalid JSON is received.
  // TODO: Implement end handling


  // Handle request errors.
  // TODO: Reject the Promise when an error occurs
}


function parseCookies(req) {

  // Read the Cookie header from the incoming request.
  // If no cookie header exists, use an empty value.
  // TODO: Get the cookie header


  // Create an object to store individual cookies.
  // TODO: Create the cookies object


  // Separate multiple cookies and process each one.
  // Extract the cookie name and value.
  // Decode the cookie value before storing it.
  // TODO: Implement cookie parsing


  // Return all parsed cookies.
  // TODO: Return the cookies object
}


function setSessionCookie(token) {

  // Create a cookie containing the session token.
  // The cookie must:
  // - Use the name "session_id"
  // - Encode the token safely
  // - Prevent client-side JavaScript access
  // - Use SameSite protection
  // - Expire after 30 minutes
  // - Be available throughout the application
  // TODO: Return the session cookie string
}


function clearSessionCookie() {

  // Create a cookie that removes the existing session.
  // Use the same cookie name and security settings
  // used when creating the session cookie.
  // Set its lifetime so that the browser removes it.
  // TODO: Return the cookie-clearing string
}


// Export all utility functions so they can be used by other files.
// TODO: Export all five functions
module.exports = {

};