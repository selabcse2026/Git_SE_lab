// Import the required modules for creating the HTTP server and working with MongoDB
// TODO: Add the required imports


// Import database connection functionality
// TODO: Add the database connection import


// Import the required utility functions for handling JSON, cookies and sessions
// TODO: Add the required utility imports


// Import the required authentication and authorization functions
// TODO: Add the required authentication imports


// Define the server port
// Use an externally provided port when available, otherwise use port 3000
// TODO: Define the port


// Define the frontend origins that are allowed to access this server
// TODO: Create a collection containing the two allowed localhost origins


function applyCors(req, res) {

  // Read the origin sent by the client
  // TODO: Get the request origin


  // If the request does not contain an origin, allow the request
  // TODO: Handle requests without an origin


  // Check whether the origin is present in the list of allowed origins
  // If it is not allowed, send a forbidden response
  // TODO: Validate the origin


  // Set the required response headers to allow the approved origin
  // and allow cookies to be sent with requests
  // TODO: Set the CORS response headers


  // Return whether the request is allowed
  // TODO: Return the appropriate result
}


function handlePreflight(req, res) {

  // Check whether the request is an OPTIONS request
  // TODO: Identify preflight requests


  // Specify the HTTP methods supported by the server
  // TODO: Set the allowed methods


  // Specify the request headers accepted by the server
  // TODO: Set the allowed headers


  // Send an empty successful response for the preflight request
  // TODO: Complete the preflight response


  // Indicate that the preflight request has been handled
  // TODO: Return the appropriate result
}


function validObjectId(id) {

  // Check whether the supplied ID is a valid MongoDB ObjectId
  // and ensure that its format matches the original value
  // TODO: Implement the validation
}


function cleanAppointment(doc) {

  // Convert MongoDB-specific ID values into strings
  // before sending appointment information to the client
  // TODO: Return a cleaned appointment object
}


async function serverHandler(req, res) {

  // Validate the request origin
  // Stop processing if the origin is not allowed
  // TODO: Apply CORS validation


  // Handle OPTIONS requests before processing other routes
  // TODO: Handle preflight requests


  // Connect to the database
  // TODO: Get the database instance


  // Access the users collection
  // TODO: Create a reference to the users collection


  // Access the appointments collection
  // TODO: Create a reference to the appointments collection


  // Create a URL object from the incoming request
  // TODO: Parse the request URL


  // Extract the requested path
  // TODO: Get the pathname


  // ============================================================
  // ROUTE 1: POST /login
  // ============================================================

  // Accept email and password from the request body
  // Validate that both values are provided
  // Find a matching user in the database
  // Reject invalid credentials
  // Create a session for a valid user
  // Send the session token to the client using a cookie
  // Return the user's role after successful login
  // TODO: Implement login


  // ============================================================
  // ROUTE 2: POST /logout
  // ============================================================

  // Verify that the user has an active session
  // Delete the current session
  // Clear the session cookie
  // Return a successful logout response
  // TODO: Implement logout


  // ============================================================
  // ROUTE 3: GET /health
  // ============================================================

  // Return a simple response indicating that the server is running
  // TODO: Implement health check


  // ============================================================
  // ROUTE 4: GET /session
  // ============================================================

  // Check whether the client has a valid session
  // If no valid session exists, return an unauthorized response
  // Otherwise return the user ID, role and session expiry time
  // TODO: Implement session information route


  // ============================================================
  // ROUTE 5: POST /appointments
  // ============================================================

  // Only patients and administrators are allowed to create appointments
  // TODO: Check the user's role


  // Read the appointment information from the request body
  // Required information:
  // doctor ID, appointment date, appointment time and reason
  // TODO: Read and validate the request body


  // Validate the doctor ID
  // TODO: Validate the doctor identifier


  // Confirm that the specified user exists and has the doctor role
  // TODO: Find the doctor


  // For a patient, use the logged-in user's ID as the patient ID
  // For an administrator, accept a patient ID from the request
  // and verify that the patient exists
  // TODO: Determine and validate the patient


  // Create a new appointment containing:
  // patient, doctor, date, time, reason, status,
  // creator and creation timestamp
  // TODO: Create the appointment object


  // Store the appointment in MongoDB
  // Return the newly created appointment ID
  // TODO: Insert the appointment


  // Handle duplicate appointment conflicts
  // Return an appropriate conflict response
  // TODO: Handle duplicate booking errors


  // ============================================================
  // ROUTE 6: GET /appointments
  // ============================================================

  // Only doctors and administrators can access appointments
  // TODO: Check the user's role


  // Doctors should receive only appointments assigned to them
  // Administrators should receive all appointments
  // TODO: Build the appropriate database query


  // Retrieve the matching appointments
  // Convert MongoDB IDs into client-friendly values
  // Return the appointment list
  // TODO: Fetch and return appointments


  // Match URLs in the format:
  // /appointments/<appointmentId>
  // TODO: Extract the appointment ID from the URL


  // ============================================================
  // ROUTE 7: PUT /appointments/:appointmentId
  // ============================================================

  // Only administrators can update appointments
  // TODO: Check administrator authorization


  // Read the fields supplied for updating
  // TODO: Read the request body


  // If a doctor ID is supplied:
  // validate it and confirm that the doctor exists
  // TODO: Validate the doctor


  // If a patient ID is supplied:
  // validate it and confirm that the patient exists
  // TODO: Validate the patient


  // Allow the following appointment fields to be updated:
  // appointment date, appointment time, reason and status
  // TODO: Process the allowed fields


  // Reject the request if there are no valid fields to update
  // TODO: Validate the update object


  // Add the time at which the appointment was modified
  // TODO: Store the update timestamp


  // Update the appointment in MongoDB using its ID
  // TODO: Perform the update operation


  // If no appointment matches the given ID, return not found
  // TODO: Handle missing appointment


  // Handle duplicate appointment conflicts
  // TODO: Handle duplicate booking errors


  // ============================================================
  // ROUTE 8: DELETE /appointments/:appointmentId
  // ============================================================

  // Only administrators can delete appointments
  // TODO: Check administrator authorization


  // Delete the appointment using the appointment ID
  // TODO: Perform the delete operation


  // If no appointment was deleted, return not found
  // TODO: Handle missing appointment


  // Return a successful deletion response
  // TODO: Send the response


  // ============================================================
  // UNKNOWN ROUTE
  // ============================================================

  // Return a not-found response when no route matches
  // TODO: Send the appropriate response
}


// Create the HTTP server
// TODO: Create the server and connect incoming requests to serverHandler


// Handle unexpected errors from the request handler
// Log the error and return an internal server error response
// TODO: Add error handling


// Start the server on the configured port
// TODO: Start listening and display the server URL