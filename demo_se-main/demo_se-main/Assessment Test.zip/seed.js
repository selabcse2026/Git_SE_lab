const { connectDB, closeDB } = require('./db');

async function seed() {
  const db = await connectDB();
  const users = db.collection('users');
  const appointments = db.collection('appointments');

  await users.deleteMany({});
  await appointments.deleteMany({});

  const result = await users.insertMany([
    {
      name: 'System Admin',
      email: 'admin@test.com',
      password: 'admin123',
      role: 'admin'
    },
    {
      name: 'Dr. Meera Rao',
      email: 'doctor@test.com',
      password: 'doctor123',
      role: 'doctor',
      specialization: 'General Medicine'
    },
    {
      name: 'Test Patient',
      email: 'patient@test.com',
      password: 'patient123',
      role: 'patient'
    }
  ]);

  const adminId = result.insertedIds[0];
  const doctorId = result.insertedIds[1];
  const patientId = result.insertedIds[2];

  const appt = await appointments.insertOne({
    patientId,
    doctorId,
    appointmentDate: '2026-09-10',
    appointmentTime: '10:30',
    reason: 'General consultation',
    status: 'scheduled',
    createdBy: adminId,
    createdAt: new Date()
  });

  await appointments.createIndex(
    { doctorId: 1, appointmentDate: 1, appointmentTime: 1 },
    { unique: true }
  );

  console.log('Seed complete.');
  console.log('Admin: admin@test.com / admin123');
  console.log('Doctor: doctor@test.com / doctor123');
  console.log('Patient: patient@test.com / patient123');
  console.log('DOCTOR_ID:', doctorId.toString());
  console.log('PATIENT_ID:', patientId.toString());
  console.log('APPOINTMENT_ID:', appt.insertedId.toString());
}

seed()
  .catch(err => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(closeDB);
