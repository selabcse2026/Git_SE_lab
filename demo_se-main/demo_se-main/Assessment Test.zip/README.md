# Hospital Appointment Management Backend

Simple backend built with:

- Node.js built-in `http` server
- MongoDB using `MongoClient`
- In-memory sessions using `Map`
- Cookies
- CORS
- RBAC
- No Express
- No MongoDB aggregation

## Roles

- Admin
- Doctor
- Patient

## Exactly 2 non-admin role-specific CRUD operations

1. Patient -> Create Appointment (`POST /appointments`)
2. Doctor -> Read Appointments (`GET /appointments`)

Admin can create, read, update and delete appointments.

## Exactly 8 routes

1. `POST /login`
2. `POST /logout`
3. `GET /health`
4. `GET /session`
5. `POST /appointments`
6. `GET /appointments`
7. `PUT /appointments/:appointmentId`
8. `DELETE /appointments/:appointmentId`

## Run

```bash
npm install
npm run seed
npm start
```

Base URL:

```text
http://localhost:3000
```

## Seed users

### Admin

```text
admin@test.com
admin123
```

### Doctor

```text
doctor@test.com
doctor123
```

### Patient

```text
patient@test.com
patient123
```

`npm run seed` also prints `DOCTOR_ID`, `PATIENT_ID`, and `APPOINTMENT_ID`.

## Session

- Stored in an in-memory `Map`
- Token generated using `crypto.randomBytes(32)`
- Duration: 30 minutes
- Cookie: `session_id`
- `HttpOnly`
- `SameSite=Lax`
- `Max-Age=1800`

## Example login

```http
POST /login
Content-Type: application/json
```

```json
{
  "email": "patient@test.com",
  "password": "patient123"
}
```

## Patient: Create Appointment

```http
POST /appointments
Content-Type: application/json
```

```json
{
  "doctorId": "DOCTOR_ID",
  "appointmentDate": "2026-09-20",
  "appointmentTime": "11:30",
  "reason": "Follow-up consultation"
}
```

A patient cannot use `GET /appointments`.

## Doctor: Read Appointments

```http
GET /appointments
```

A doctor sees only appointments assigned to that doctor's user ID.
A doctor cannot create, update, or delete appointments.

## Admin: Create Appointment

Admin provides both `patientId` and `doctorId`.

```json
{
  "patientId": "PATIENT_ID",
  "doctorId": "DOCTOR_ID",
  "appointmentDate": "2026-09-21",
  "appointmentTime": "12:00",
  "reason": "Admin-created appointment"
}
```

## Admin: Update Appointment

```http
PUT /appointments/APPOINTMENT_ID
```

Possible fields:

```json
{
  "appointmentDate": "2026-09-22",
  "appointmentTime": "14:00",
  "reason": "Updated consultation",
  "status": "confirmed"
}
```

## Admin: Delete Appointment

```http
DELETE /appointments/APPOINTMENT_ID
```

## Appointment constraint

MongoDB unique index:

```text
doctorId + appointmentDate + appointmentTime
```

The same doctor cannot be booked for two appointments at the same date and time.
Duplicate key error `11000` returns HTTP `409`.

## CORS configuration

Allowed origins:

```text
http://localhost:5500
http://127.0.0.1:5500
```

Cookies require frontend requests to use:

```js
credentials: "include"
```

## CORS Task 1 - Allowed origin

Run a frontend from `http://localhost:5500` and call:

```js
fetch("http://localhost:3000/login", {
  method: "POST",
  credentials: "include",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    email: "patient@test.com",
    password: "patient123"
  })
});
```

Then create an appointment using another `fetch()` request with `credentials: "include"`.

Expected:

- Login returns `200`
- Cookie is stored
- Protected request succeeds
- `Access-Control-Allow-Origin` matches the frontend origin
- `Access-Control-Allow-Credentials: true`

## CORS Task 2 - Blocked origin

Send a request with an unapproved origin such as:

```text
http://localhost:5501
```

Example:

```bash
curl -i -H "Origin: http://localhost:5501" http://localhost:3000/health
```

Expected:

```text
403
```

```json
{
  "error": "CORS origin not allowed"
}
```
