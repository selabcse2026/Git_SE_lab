// server.js
// A simple Book Store server using ONLY Node's built-in http module (no Express).
// Uses MongoDB (native driver) for storage and "formidable" only to read
// file uploads (book images) from multipart form submissions.

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const { ObjectId } = require('mongodb');
const { IncomingForm } = require('formidable');

const { connectDB, getDB } = require('./db');

const PORT = 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

// Make sure the uploads folder exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR);
}

// The shopping cart is kept in memory (simple array), which is enough
// for a single-user learning project. Each item: { bookId, title, price, qty }
let cart = [];

// ---------- small helpers ----------

// Send a JSON response
function sendJSON(res, statusCode, data) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

// Serve a static file (html, css, js, images) from disk
function serveStaticFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const types = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp'
  };

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('File not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

// Read and collect JSON body for simple (non file-upload) POST requests
function readJSONBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

// ---------- book routes ----------

// GET /api/books  -> return all books
async function getBooks(req, res) {
  const db = getDB();
  const books = await db.collection('books').find().toArray();
  sendJSON(res, 200, books);
}

// POST /api/books/add  -> add a new book (multipart form: title, author, price, image)
function addBook(req, res) {
  const form = new IncomingForm({ uploadDir: UPLOADS_DIR, keepExtensions: true });

  form.parse(req, async (err, fields, files) => {
    if (err) return sendJSON(res, 400, { error: 'Could not parse form data' });

    const title = fields.title?.[0] || fields.title;
    const author = fields.author?.[0] || fields.author;
    const price = parseFloat(fields.price?.[0] || fields.price);

    // formidable v3 puts the file in files.image (may be an array)
    const imageFile = Array.isArray(files.image) ? files.image[0] : files.image;
    const imageName = imageFile ? path.basename(imageFile.filepath) : null;

    const db = getDB();
    const result = await db.collection('books').insertOne({
      title,
      author,
      price,
      image: imageName
    });

    sendJSON(res, 201, { message: 'Book added', bookId: result.insertedId });
  });
}

// POST /api/books/update?id=xxx -> update book details (title/author/price, optional new image)
function updateBook(req, res, bookId) {
  const form = new IncomingForm({ uploadDir: UPLOADS_DIR, keepExtensions: true });

  form.parse(req, async (err, fields, files) => {
    if (err) return sendJSON(res, 400, { error: 'Could not parse form data' });

    const updatedData = {
      title: fields.title?.[0] || fields.title,
      author: fields.author?.[0] || fields.author,
      price: parseFloat(fields.price?.[0] || fields.price)
    };

    const imageFile = Array.isArray(files.image) ? files.image[0] : files.image;
    if (imageFile) {
      updatedData.image = path.basename(imageFile.filepath);
    }

    const db = getDB();
    await db.collection('books').updateOne(
      { _id: new ObjectId(bookId) },
      { $set: updatedData }
    );

    sendJSON(res, 200, { message: 'Book updated' });
  });
}

// POST /api/books/delete?id=xxx -> delete a book by its id
async function deleteBook(req, res, bookId) {
  const db = getDB();

  // remove the image file too, if it exists
  const book = await db.collection('books').findOne({ _id: new ObjectId(bookId) });
  if (book && book.image) {
    const imgPath = path.join(UPLOADS_DIR, book.image);
    fs.unlink(imgPath, () => {}); // ignore errors, e.g. file already missing
  }

  await db.collection('books').deleteOne({ _id: new ObjectId(bookId) });

  // also remove it from the cart if it was added
  cart = cart.filter((item) => item.bookId !== bookId);

  sendJSON(res, 200, { message: 'Book deleted' });
}

// ---------- cart routes ----------

// POST /api/cart/add?id=xxx -> add a book to the cart
async function addToCart(req, res, bookId) {
  const db = getDB();
  const book = await db.collection('books').findOne({ _id: new ObjectId(bookId) });

  if (!book) return sendJSON(res, 404, { error: 'Book not found' });

  const existing = cart.find((item) => item.bookId === bookId);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ bookId: bookId, title: book.title, price: book.price, qty: 1 });
  }

  sendJSON(res, 200, { message: 'Added to cart', cart });
}

// POST /api/cart/remove?id=xxx -> remove one book from the cart
function removeFromCart(req, res, bookId) {
  cart = cart.filter((item) => item.bookId !== bookId);
  sendJSON(res, 200, { message: 'Removed from cart', cart });
}

// GET /api/cart -> return cart items and the total cost
function getCart(req, res) {
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  sendJSON(res, 200, { items: cart, total });
}

// ---------- main request router ----------

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  try {
    // ----- API routes -----
    if (pathname === '/api/books' && method === 'GET') {
      return await getBooks(req, res);
    }

    if (pathname === '/api/books/add' && method === 'POST') {
      return addBook(req, res);
    }

    if (pathname === '/api/books/update' && method === 'POST') {
      return updateBook(req, res, parsedUrl.query.id);
    }

    if (pathname === '/api/books/delete' && method === 'POST') {
      return await deleteBook(req, res, parsedUrl.query.id);
    }

    if (pathname === '/api/cart' && method === 'GET') {
      return getCart(req, res);
    }

    if (pathname === '/api/cart/add' && method === 'POST') {
      return await addToCart(req, res, parsedUrl.query.id);
    }

    if (pathname === '/api/cart/remove' && method === 'POST') {
      return removeFromCart(req, res, parsedUrl.query.id);
    }

    // ----- uploaded images -----
    if (pathname.startsWith('/uploads/') && method === 'GET') {
      const filePath = path.join(UPLOADS_DIR, path.basename(pathname));
      return serveStaticFile(res, filePath);
    }

    // ----- static frontend files -----
    if (method === 'GET') {
      let filePath = pathname === '/' ? '/index.html' : pathname;
      filePath = path.join(PUBLIC_DIR, filePath);
      return serveStaticFile(res, filePath);
    }

    // fallback
    sendJSON(res, 404, { error: 'Route not found' });
  } catch (error) {
    console.error(error);
    sendJSON(res, 500, { error: 'Server error', details: error.message });
  }
});

// ---------- start the server ----------

connectDB().then(() => {
  server.listen(PORT, () => {
    console.log(`Book Store server running at http://localhost:${PORT}`);
  });
}).catch((err) => {
  console.error('Failed to connect to MongoDB:', err.message);
});
