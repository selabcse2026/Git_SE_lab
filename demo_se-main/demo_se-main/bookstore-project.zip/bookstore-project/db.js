// db.js
// Small helper to connect to MongoDB once and reuse the same connection.

const { MongoClient } = require('mongodb');

const MONGO_URL = 'mongodb://localhost:27017'; // change if your MongoDB runs elsewhere
const DB_NAME = 'bookstore';

let db = null;

async function connectDB() {
  const client = new MongoClient(MONGO_URL);
  await client.connect();
  db = client.db(DB_NAME);
  console.log('Connected to MongoDB database:', DB_NAME);
  return db;
}

function getDB() {
  if (!db) {
    throw new Error('Database not connected yet. Call connectDB() first.');
  }
  return db;
}

module.exports = { connectDB, getDB };
