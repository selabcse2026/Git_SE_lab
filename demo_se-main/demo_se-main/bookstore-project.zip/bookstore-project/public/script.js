// script.js
// Talks to the backend API and updates the page. No frameworks, plain JS.

const bookForm = document.getElementById('bookForm');
const bookList = document.getElementById('bookList');
const cartList = document.getElementById('cartList');
const cartTotal = document.getElementById('cartTotal');
const formTitle = document.getElementById('formTitle');
const submitBtn = document.getElementById('submitBtn');
const cancelEditBtn = document.getElementById('cancelEditBtn');
const bookIdField = document.getElementById('bookId');

// ---------- load & render books ----------

async function loadBooks() {
  const res = await fetch('/api/books');
  const books = await res.json();

  bookList.innerHTML = '';

  books.forEach((book) => {
    const col = document.createElement('div');
    col.className = 'col-md-3 book-card';

    const imageSrc = book.image ? `/uploads/${book.image}` : 'https://via.placeholder.com/200x180?text=No+Image';

    col.innerHTML = `
      <div class="card h-100">
        <img src="${imageSrc}" class="card-img-top" alt="${book.title}">
        <div class="card-body d-flex flex-column">
          <h6 class="card-title">${book.title}</h6>
          <p class="card-text mb-1">By ${book.author}</p>
          <p class="card-text fw-bold">₹${book.price}</p>
          <div class="mt-auto d-flex flex-column gap-2">
            <button class="btn btn-sm btn-success" onclick="addToCart('${book._id}')">Add to Cart</button>
            <button class="btn btn-sm btn-outline-primary" onclick='editBook(${JSON.stringify(book)})'>Edit</button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteBook('${book._id}')">Delete</button>
          </div>
        </div>
      </div>
    `;

    bookList.appendChild(col);
  });
}

// ---------- add / update book ----------

bookForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const formData = new FormData();
  formData.append('title', document.getElementById('title').value);
  formData.append('author', document.getElementById('author').value);
  formData.append('price', document.getElementById('price').value);

  const imageFile = document.getElementById('image').files[0];
  if (imageFile) formData.append('image', imageFile);

  const id = bookIdField.value;

  if (id) {
    // update existing book
    await fetch(`/api/books/update?id=${id}`, { method: 'POST', body: formData });
  } else {
    // add new book
    await fetch('/api/books/add', { method: 'POST', body: formData });
  }

  resetForm();
  loadBooks();
});

function editBook(book) {
  formTitle.textContent = 'Edit Book';
  submitBtn.textContent = 'Update Book';
  cancelEditBtn.classList.remove('d-none');

  bookIdField.value = book._id;
  document.getElementById('title').value = book.title;
  document.getElementById('author').value = book.author;
  document.getElementById('price').value = book.price;
}

cancelEditBtn.addEventListener('click', resetForm);

function resetForm() {
  bookForm.reset();
  bookIdField.value = '';
  formTitle.textContent = 'Add a New Book';
  submitBtn.textContent = 'Add Book';
  cancelEditBtn.classList.add('d-none');
}

// ---------- delete book ----------

async function deleteBook(id) {
  if (!confirm('Delete this book?')) return;
  await fetch(`/api/books/delete?id=${id}`, { method: 'POST' });
  loadBooks();
  loadCart();
}

// ---------- cart ----------

async function addToCart(id) {
  await fetch(`/api/cart/add?id=${id}`, { method: 'POST' });
  loadCart();
}

async function removeFromCart(id) {
  await fetch(`/api/cart/remove?id=${id}`, { method: 'POST' });
  loadCart();
}

async function loadCart() {
  const res = await fetch('/api/cart');
  const data = await res.json();

  cartList.innerHTML = '';
  data.items.forEach((item) => {
    const li = document.createElement('li');
    li.className = 'list-group-item d-flex justify-content-between align-items-center';
    li.innerHTML = `
      ${item.title} (x${item.qty}) - ₹${(item.price * item.qty).toFixed(2)}
      <button class="btn btn-sm btn-outline-danger" onclick="removeFromCart('${item.bookId}')">Remove</button>
    `;
    cartList.appendChild(li);
  });

  cartTotal.textContent = data.total.toFixed(2);
}

// ---------- initial load ----------

loadBooks();
loadCart();
