# Book Store Project

A simple Book Store web app built with:
- **Frontend:** HTML, CSS, Bootstrap (local files, not CDN)
- **Backend:** Node.js core `http` module only (no Express)
- **Database:** MongoDB (native `mongodb` driver)
- **File upload:** `formidable` (only used to read uploaded images)

## Features
- Add a book (title, author, price, image)
- Delete a book by id
- Update book details (and optionally replace the image)
- Add a book to the cart
- View cart with total cost

## Folder structure
```
bookstore-project/
  server.js        -> main server (routes, request handling)
  db.js             -> MongoDB connection
  package.json
  public/
    index.html
    style.css
    script.js
    bootstrap/       -> local Bootstrap css/js
  uploads/           -> uploaded book images get saved here
```

## Setup

1. Make sure MongoDB is installed and running locally
   (default connection used: `mongodb://localhost:27017`)

2. Install dependencies:
   ```
   npm install
   ```

3. Start the server:
   ```
   npm start
   ```

4. Open your browser at:
   ```
   http://localhost:3000
   ```

## Notes
- The database name used is `bookstore`, and books are stored in a
  `books` collection — MongoDB creates both automatically the first
  time you add a book.
- The cart is kept in server memory for simplicity, so it resets
  when you restart the server.
- If your MongoDB runs somewhere else, change `MONGO_URL` in `db.js`.
